export const environment = {
  production: true,
  firebaseConfig : {
    apiKey: "AIzaSyBbBR66J1wveyPqV8qU1cBg45U0O1I8Sso",
    authDomain: "capable-respect-315112.firebaseapp.com",
    projectId: "capable-respect-315112",
    storageBucket: "capable-respect-315112.appspot.com",
    messagingSenderId: "583381481151",
    appId: "1:583381481151:web:a79280575bc55ce8e1f80a",
    measurementId: "G-0BPFHEVXM2"
  
  }
};
