import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class TopHeadlineService {

  apiKey :any;


  constructor(private http: HttpClient) {
    
    this.getApiKey();
  }

  getApiKey(){
   this.http.get("assets/config/config.json").subscribe(data =>{
     console.log("config data--->",data);
     this.apiKey = data['apiKey'];
     console.log("this.apiKey--->",this.apiKey);
   })
  }

  getTopHeadlines() {

    // this.getApiKey();

    let country = "in";
    let category = "business";

    let params = new HttpParams();
    params = params.set("country", country);
    params = params.set("category", category);
    params = params.set("apiKey", this.apiKey);

    return this.http.get(`https://newsapi.org/v2/top-headlines`, { params });

  }


  getSearchedRecord(data:string){


    let params = new HttpParams();
    
    params = params.set("q", data);
    params = params.set("apiKey", this.apiKey);

    return this.http.get(`http://newsapi.org/v2/everything`, { params });

  }


}
