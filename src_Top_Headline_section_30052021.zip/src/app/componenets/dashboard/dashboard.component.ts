import { THIS_EXPR } from '@angular/compiler/src/output/output_ast';
import { Component, OnDestroy, OnInit } from '@angular/core';
import { AuthService } from 'src/app/services/auth/auth.service';
import { DashboardService } from 'src/app/services/dashboard/dashboard.service';
import * as _ from 'lodash';
import { Observable, Subscription, timer } from 'rxjs';


@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css'],
})
export class DashboardComponent implements OnInit, OnDestroy {

  allTopHeading: any = [];
  searchText: any = "";
  p: number = 1;
  paginationConfig: any;

  subscription: Subscription;
  everyFiveSeconds: Observable<number> = timer(0, 60000); //repeat after every 1 min 


  constructor(private authService: AuthService, private dashboardsService: DashboardService) { }



  ngOnInit() {

    this.subscription = this.everyFiveSeconds.subscribe(() => {
      
      this.getSearchData();
      

    });



  }

  ngOnDestroy() {
    this.subscription.unsubscribe();
  }

  async getTopHeadlines() {


    await this.dashboardsService.getTopHeadlines().subscribe((res: any) => {
      console.log("getTopHeadlines res--->", res);

      if (res != null && res.articles != null) {
        this.allTopHeading = res.articles;
        console.log("allTopHeading--->", this.allTopHeading, "count--->", this.allTopHeading.length);
      }
    })

    this.setPaginationConfig();

  }

  setPaginationConfig() {
    this.paginationConfig = {
      itemsPerPage: 5,
      currentPage: 1,
      totalItems: this.allTopHeading.length
    };
  }


  getSearchData() {
    if (this.searchText == "") {
      this.getTopHeadlines();
      console.log("search if block--->", this.allTopHeading.length)
    } else {


      this.dashboardsService.getSearchedRecord(this.searchText).subscribe((res:any)=>{
        console.log("search res--->",res);

        if (res != null && res.articles != null) {
          this.allTopHeading = res.articles;
          console.log("allTopHeading--searched->", this.allTopHeading, "count--->", this.allTopHeading.length);
        }


      })
      // this.allTopHeading = this.allTopHeading.filter((val) => val.title.toLowerCase().includes(this.searchText));
      console.log("search else block--->", this.allTopHeading.length)


    }

    this.setPaginationConfig();

  }


  pageChanged(event) {
    this.paginationConfig.currentPage = event;
  }

  viewFullArticle(url: string) {
    window.open(`${url}`, "_blank");
  }

}
