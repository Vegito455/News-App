
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

import { AuthService } from 'src/app/services/auth/auth.service';
import { EncryptDecryptService } from 'src/app/shared/ecrypt-decrypt/encrypt-decrypt.service';
import { User } from '../../shared/User';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  isLogin: boolean;
  userData = this.authService.user;

  currentUserData: any;
  loginFlag: any=false;
  imageURL: any;
  userName: string='';




  constructor(private authService: AuthService, private encdecService: EncryptDecryptService,private router :Router) { }

  
  ngOnInit() {

    // this.currentUserData = ;
    this.CheckCurrentUser()
    console.log("this.currentUserData--->", this.currentUserData);
    /* this.CheckIfUserAlreadyLogin(); */


  }
  /* 
    CheckIfUserAlreadyLogin() {
      console.log("CheckIfUserAlreadyLogin fn called--->");
      this.userData2 = this.authService.CheckIfUserAlreadyLogin();
      this.userData = this.authService.user;
      console.log('this.userData--->',this.userData);
      console.log('this.userData2--->',this.userData2);
      this.isLogin = (this.authService.user != null) ? true : false;
      console.log("loginFlag--->", this.isLogin);
    }
     */

  async loginWithPopUp() {
    await this.authService.loginWithGoogle();
    this.CheckCurrentUser();
    // window.location.reload();
    this.router.navigate(['/home']);
    console.log("this.currentUserData header---->", this.currentUserData);
  }

  async Signout() {
    await this.authService.SignOut();
    this.CheckCurrentUser();
    // window.location.reload();
    this.router.navigate(['/home']);

  }

  CheckCurrentUser() {

    this.loginFlag = (localStorage.getItem('data') != null || localStorage.getItem('data') != undefined) ? true : false;
    console.log('loginFlag', this.loginFlag);

    if (this.loginFlag) {
      this.currentUserData = this.encdecService.decryptJson(localStorage.getItem('data'));
      this.imageURL = this.currentUserData.photoURL;
      this.userName = this.currentUserData.displayName;
      
    }
    console.log("this.currentUserData header---->", this.currentUserData);

  }



}
